wget https://courses.cs.washington.edu/courses/cse455/10wi/projects/project4/psmImages_png.zip
unzip psmImages_png.zip
rm psmImages_png.zip
